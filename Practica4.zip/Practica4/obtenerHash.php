<?php
echo password_hash("root", PASSWORD_BCRYPT)."\n";
?>